const express = require('express');
const path = require('path');
const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname)));

app.get('/',
	(req, res) => {
		res.sendFile(__dirname + '/index.html');
	});

app.get('/login',
	(req, res) => {
		res.sendFile(__dirname + '/login.html');
	});
app.get('/register',
	(req, res) => {
		res.sendFile(__dirname + '/register.html');
	});
app.get('/welcome',
	(req, res) => {
		res.sendFile(__dirname + '/success.html');
	});
app.post('/register', (req, res) => {
    // Store registration data in local storage via client-side script
    res.redirect('/login');
});

app.post('/login', (req, res) => {
    // Login is handled client-side with localStorage
    res.redirect('/welcome');
});

app.listen(3000,
	() => {
		console.log(
			'Our express server is up on port 3000'
		);
	});
