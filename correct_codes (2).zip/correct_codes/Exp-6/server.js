const express = require("express");
const path = require("path");
const fs = require("fs");
const jwt = require("jsonwebtoken");

const app = express();
const port = 3000;
const SECRET = "secret"; // Use env in production

// Middleware
app.use(express.json());

// Load user database synchronously
let database = JSON.parse(fs.readFileSync("database.json", "utf8"));

// Serve login page
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "login.html"));
});

// Auth endpoint: validate user and generate token
app.post("/auth", (req, res) => {
  const { name, password } = req.body;

  const user = database.find(
    (u) => u.name === name && u.password === password
  );

  if (user) {
    const token = jwt.sign(user, SECRET, { expiresIn: "1h" });

    res.status(200).json({
      login: true,
      token: token,
      data: user,
    });
  } else {
    res.status(401).json({
      login: false,
      error: "Invalid credentials",
    });
  }
});

// Verify token
app.post("/verifyToken", (req, res) => {
  const { token } = req.body;

  try {
    const decoded = jwt.verify(token, SECRET);
    res.status(200).json({
      login: true,
      data: decoded,
    });
  } catch (err) {
    res.status(401).json({
      login: false,
      error: "Token invalid or expired",
    });
  }
});

// Start server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}/`);
});
