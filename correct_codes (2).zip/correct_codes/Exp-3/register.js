function validateForm(event) {
    event.preventDefault();
    
    const form = document.forms['frm'];
    if (!form) return false;
    
    // Get form values
    const firstName = form.fname.value.trim();
    const lastName = form.lname.value.trim();
    const phone = form.phone.value.trim();
    const email = form.mailid.value.trim();
    const password = form.pwd.value;
    const age = form.age.value.trim();
    const gender = form.gender.value;
    const dob = form.dob.value;
    
    // Validate First Name (letters and spaces only, 2-50 chars)
    const nameRegex = /^[A-Za-z\s]{2,50}$/;
    if (!nameRegex.test(firstName)) {
        alert('Please enter a valid first name (2-50 letters and spaces only)');
        form.fname.focus();
        return false;
    }
    
    // Validate Last Name (letters and spaces only, 2-50 chars)
    if (!nameRegex.test(lastName)) {
        alert('Please enter a valid last name (2-50 letters and spaces only)');
        form.lname.focus();
        return false;
    }
    
    // Validate Phone (exactly 10 digits)
    const phoneRegex = /^\d{10}$/;
    if (!phoneRegex.test(phone)) {
        alert('Please enter a valid 10-digit phone number');
        form.phone.focus();
        return false;
    }
    
    // Validate Email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        alert('Please enter a valid email address');
        form.mailid.focus();
        return false;
    }
    
    // Validate Password (8-20 chars, at least one letter and one number)
    const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d@$!%*#?&]{8,20}$/;
    if (!passwordRegex.test(password)) {
        alert('Password must be 8-20 characters long and include at least one letter and one number');
        form.pwd.focus();
        return false;
    }
    
    // Validate Age (1-120)
    const ageNum = parseInt(age, 10);
    if (isNaN(ageNum) || ageNum < 1 || ageNum > 120) {
        alert('Please enter a valid age (1-120)');
        form.age.focus();
        return false;
    }
    
    // Validate Date of Birth
    if (!dob) {
        alert('Please enter your date of birth');
        form.dob.focus();
        return false;
    }
    
    // Validate Gender
    if (!gender) {
        alert('Please select your gender');
        return false;
    }
    
    // Store user data (in a real app, this would be sent to a server)
    try {
        localStorage.setItem('userFirstName', firstName);
        localStorage.setItem('userLastName', lastName);
        localStorage.setItem('userPhone', phone);
        localStorage.setItem('userEmail', email);
        localStorage.setItem('userPassword', password); // In a real app, hash the password
        localStorage.setItem('userAge', age);
        localStorage.setItem('userGender', gender);
        localStorage.setItem('userDOB', dob);
        
        alert('Registration successful! You can now log in.');
        window.location.href = 'login.html';
        return true;
    } catch (e) {
        console.error('Error saving to localStorage:', e);
        alert('An error occurred during registration. Please try again.');
        return false;
    }
}

// Add event listener when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', function() {
    const form = document.forms['frm'];
    if (form) {
        form.addEventListener('submit', validateForm);
    }
});