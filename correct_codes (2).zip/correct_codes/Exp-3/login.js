function LoginValidate(event) {
    event.preventDefault(); // Prevent form submission
    
    const enterEmail = document.getElementById('email').value.trim();
    const enterPassword = document.getElementById('pwd').value;

    // Retrieve user data from localStorage
    const storedEmail = localStorage.getItem('userEmail');
    const storedPassword = localStorage.getItem('userPassword');
    
    if (!storedEmail || !storedPassword) {
        alert('No registered user found. Please register first.');
        window.location.href = 'register.html';
        return false;
    }

    if (enterEmail.toLowerCase() === storedEmail.toLowerCase()) {
        if (enterPassword === storedPassword) {
            alert('Login successful!');
            window.location.href = 'welcome.html';
            return true;
        } else {
            alert('Incorrect password. Please try again.');
            document.getElementById('pwd').value = '';
            document.getElementById('pwd').focus();
            return false;
        }
    } else {
        alert('No account found with this email. Please register first.');
        window.location.href = 'register.html';
        return false;
    }
}

// Add event listener to the form
document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.querySelector('form');
    if (loginForm) {
        loginForm.addEventListener('submit', LoginValidate);
    }
});
